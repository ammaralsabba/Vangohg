# -*- coding: utf-8 -*-

{
    'name': 'Employees Release',
    'category': 'Human Resources',
    'version': '1.0',
    'description':'',
	'author': 'Mast',
    'depends': ['hr_loan'],
    'auto_install': False,
    'data': ['security/ir.model.access.csv', 'views/hr_release_view.xml'],
    'qweb': [],
}
